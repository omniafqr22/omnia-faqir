package document;

public class TestBiblioth�que {
	public static void main(String[] args){
	     Biblioth�que bib=new Biblioth�que(10);
	     Document d1=new Document(12,"Base_de_donnee");
	     bib.ajouter(d1);
	     Document d2=new Document(1,"JAVA");
	     bib.ajouter(d2);
	      bib.ajouter(new Document(1,"MATHS"));
	      bib.ajouter(new Document(2,"FRANCAIS"));
	      bib.ajouter(new Document(62,"ENGLISH"));
	      bib.ajouter(new Document(22,"ARABE"));
	      bib.afficherDoc();
	      System.out.println();
	      System.out.println(bib.document(2));
	      System.out.println(bib.supprimer(d2));
	      System.out.println();
	      bib.afficherDoc();
	  }  
}
