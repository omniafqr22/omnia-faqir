package document;

public class Document {
	 protected int NumEnreg;
     protected String titre;
    public Document(int NumEnreg, String titre) {
        this.NumEnreg = NumEnreg;
        this.titre = titre;
    }
    public String toString() {
        return "Document{" + "NumEnreg=" + NumEnreg + ", titre=" + titre + '}';
    }

}
