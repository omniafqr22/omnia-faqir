package document;
public class Biblioth�que {
	   public int Capacit�;
	    public static int Nb=0;
	    public Document[] Doc;
	    public Biblioth�que(int Capacit�) {
	        this.Capacit� = Capacit�;
	        Doc =new Document[5];
	        Nb=0;
	    }
	    public void afficherDoc(){
	        for(Document D:Doc)                                                    
	            System.out.println(D);
	    }
	    public Document document(int i){
	        return (Doc[i]) ;
	    }

	    public boolean ajouter(Document Doc){
	        if(Nb<Doc.NumEnreg)
	           this.Doc[Nb++]=Doc;
	        return true;
	    }
	    public boolean supprimer(Document Doc){
	        for(int i=0;i<Doc.NumEnreg;i++){
	            if(Doc[i].NumEnreg==(Doc.NumEnreg))
	              
	                    Doc[i]=Doc[i+1];
	        }
	        Nb--;
	            return true;     }
	    public void afficherAuteur(){
	        for(int i=0;i<Doc.length;i++){
	            if(Doc[i] instanceof Livre)
	                System.out.println((Livre) Doc[i]) ;
	    }
	    }
	}


	
